
public class LaminaAccion {

}
