public class Principal {
    public static void main(String[] args) {
        
    
    Comportamiento c1 = new Comportamiento();
    }
}
