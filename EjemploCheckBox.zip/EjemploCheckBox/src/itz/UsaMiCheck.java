package itz;

public class UsaMiCheck {
    public static void main(String[] args) {

        @SuppressWarnings("unused")
        MiCheck miCheck = new MiCheck();

    }

}
